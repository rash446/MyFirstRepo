export const port = parseInt(process.env.PORT || "3000", 10);
export const host = process.env.HOST || "localhost";
