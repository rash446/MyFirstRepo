'use strict';

const server = require('./server');
server.listen(8001);
